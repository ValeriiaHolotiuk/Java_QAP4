package com.skytrack.skytrack_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkytrackBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
